//var ReactCSSTransitionGroup = React.addons.CSSTransitionGroup;
'use strict';

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var placeholder = document.createElement("li");
placeholder.className = "placeholder";
var Button = ReactBootstrap.Button;
var Modal = ReactBootstrap.Modal;
var OverlayTrigger = ReactBootstrap.OverlayTrigger;

var Pie = function (_React$Component) {
	_inherits(Pie, _React$Component);

	function Pie() {
		_classCallCheck(this, Pie);

		return _possibleConstructorReturn(this, _React$Component.apply(this, arguments));
	}

	Pie.prototype.render = function render() {
		var _props = this.props;
		var color = _props.color;
		var width = _props.width;
		var progress = _props.progress;

		var pi = 3.14159265359;
		var r = 400 / 2;
		var c = 2 * pi * r;
		var realProgress = c * progress;
		return React.createElement(
			"div",
			{ className: "svg-container" },
			React.createElement(
				"div",
				{
					className: "svg-content"
				},
				React.createElement(
					"svg",
					{
						viewBox: "0 0 500 500",
						preserveAspectRatio: "xMinYMin meet"
					},
					React.createElement(
						"filter",
						{ id: "shadow" },
						React.createElement("feGaussianBlur", { "in": "SourceGraphic", stdDeviation: "15" }),
						React.createElement("feOffset", { dx: "-5", dy: "-4" })
					),
					React.createElement("circle", {

						className: "animated",
						cx: "250",
						cy: "250",
						r: "200",
						stroke: "",
						fillOpacity: "0",
						strokeWidth: width + 10,
						strokeDasharray: [realProgress, c],
						strokeDashoffset: c * progress
					}),
					React.createElement("circle", {
						filter: "url(#shadow)",
						className: "animated shadow",
						cx: "250",
						cy: "250",
						r: "200",
						stroke: color,
						fillOpacity: "0",
						strokeWidth: width,
						strokeDasharray: [realProgress, c],
						strokeDashoffset: c * progress
					}),
					React.createElement("circle", {
						className: "animated fill",
						cx: "250",
						cy: "250",
						r: "200",
						stroke: color,
						fillOpacity: "0",
						strokeWidth: width,
						strokeDasharray: [realProgress, c],
						strokeDashoffset: c * progress
					}),
					React.createElement("circle", {
						cx: "250",
						cy: "250",
						r: "200",
						stroke: color,
						fillOpacity: "0",
						strokeWidth: "5",
						strokeDasharray: [c, c],
						strokeOpacity: "0.1"
					})
				)
			)
		);
	};

	return Pie;
}(React.Component);

var Application = function (_React$Component2) {
	_inherits(Application, _React$Component2);

	function Application() {
		_classCallCheck(this, Application);

		return _possibleConstructorReturn(this, _React$Component2.apply(this, arguments));
	}

	Application.prototype.render = function render() {
		var percent = this.props.percent;
		var colorChart = this.props.colorChart;
		return React.createElement(
			"div",
			null,
			React.createElement(
				"div",
				{ className: "box" },
				React.createElement(Pie, {
					color: colorChart,
					width: 15,
					progress: percent

				})
			)
		);
	};

	return Application;
}(React.Component);

var progressUpdate;
var goals = [{
	category: 'car',
	name: 'Car',
	amount: 20000,
	progress: 6593,
	flipped: false,
	dragStatus: true
}, {
	category: 'plane',
	name: 'Vacation',
	amount: 3500,
	progress: 2984,
	flipped: false,
	dragStatus: true
}];

var dragStatus = true;

var GoalCard = function (_React$Component3) {
	_inherits(GoalCard, _React$Component3);

	function GoalCard(props) {
		_classCallCheck(this, GoalCard);

		var _this3 = _possibleConstructorReturn(this, _React$Component3.call(this, props));

		_this3.state = { condition: false,
			progress: _this3.props.item.progress,
			input1: _this3.props.item.name,
			input2: _this3.props.item.amount,
			input3: _this3.props.item.progress,
			selectValue: _this3.props.item.category
		};
		return _this3;
	}

	GoalCard.prototype.addMoney = function addMoney() {
		var addFunds = prompt('Add funds for: ' + this.props.item.name, "0");
		this.props.item.progress += Number(addFunds);
		this.setState({
			item: this.props.item
		});
	};

	GoalCard.prototype.onSave = function onSave() {
		this.props.item.progress = progressUpdate;
		this.setState({
			item: this.props.item
		});
	};

	GoalCard.prototype.editGoal = function editGoal(index) {
		this.props.onFlip(index);
		this.setState({
			condition: !this.state.condition,
			input1: this.props.item.name,
			input2: this.props.item.amount,
			input3: this.props.item.progress,
			selectValue: this.props.item.category
		});
	};

	GoalCard.prototype.deleteGoal = function deleteGoal(index) {
		this.props.onDelete(index);
		this.setState({ condition: !this.state.condition,
			input1: this.props.item.name,
			input2: this.props.item.amount,
			input3: this.props.item.progress,
			selectValue: this.props.item.category,
			flipped: false,
			dragStatus: true
		});
	};

	GoalCard.prototype.cancelEdit = function cancelEdit(index) {
		this.props.onFlip(index);
		this.setState({ condition: !this.state.condition,
			input1: this.props.item.name,
			input2: this.props.item.amount,
			input3: this.props.item.progress,
			selectValue: this.props.item.category });
	};

	GoalCard.prototype.saveGoal = function saveGoal(index) {
		this.props.onFlip(index);
		this.setState({ condition: !this.state.condition });
		this.props.item.name = this.state.input1;
		this.props.item.amount = Number(this.state.input2);
		this.props.item.progress = Number(this.state.input3);
		this.props.item.category = this.state.selectValue;
	};

	GoalCard.prototype.handleChange = function handleChange(name, e) {
		var change = {};
		change[name] = e.target.value;
		this.setState(change);
	};

	GoalCard.prototype.handleDropdown = function handleDropdown(e) {
		this.setState({ selectValue: e.target.value });
	};

	GoalCard.prototype.render = function render() {
		var message;
		var strokeColor;
		var status;
		var remaining;
		var percentRemaining;
		if (this.props.item.progress / this.props.item.amount < 1) {
			strokeColor = "#01579B";
			status = "Remaining";
			remaining = (this.props.item.amount - this.props.item.progress).toLocaleString();
			percentRemaining = "(" + ((this.props.item.amount - this.props.item.progress) / this.props.item.amount * 100).toFixed(0) + "%)";
		} else {
			strokeColor = "#7dbf69";
			status = "Exceeded";
			remaining = Math.abs(this.props.item.amount - this.props.item.progress).toLocaleString();
			percentRemaining = "(" + Math.abs((this.props.item.amount - this.props.item.progress) / this.props.item.amount * 100).toFixed(0) + "%)";
		}

		return React.createElement(
			"div",
			{ className: this.state.condition ? "flipped card-container" : "card-container" },
			React.createElement(
				"figure",
				{ className: "front" },
				React.createElement(
					"div",
					{ className: "goal--top" },
					React.createElement(
						"a",
						{ href: "#", className: "edit", onClick: this.editGoal.bind(this, this.props.item.index) },
						React.createElement("i", { className: "fa fa-pencil-square-o" })
					),
					React.createElement(
						"div",
						{ className: "goal__name" },
						this.props.item.name
					),
					React.createElement(Application, { percent: this.props.item.progress / this.props.item.amount, colorChart: strokeColor }),
					React.createElement(
						"div",
						{ className: "goal--top__container" },
						React.createElement("i", { className: 'category fa fa-' + this.props.item.category, "aria-hidden": "true" }),
						React.createElement(
							"div",
							{ className: "goal--progress" },
							React.createElement(
								"span",
								{ className: "money" },
								this.props.item.progress.toLocaleString()
							)
						),
						React.createElement(
							"div",
							{ className: "goal--amount" },
							"of ",
							React.createElement(
								"span",
								{ className: "money" },
								this.props.item.amount.toLocaleString()
							)
						)
					)
				),
				React.createElement(
					"div",
					{ className: "goal--bottom" },
					React.createElement(
						"div",
						{ className: "descriptor" },
						status,
						React.createElement(
							"span",
							{ className: "money right goal--remain" },
							remaining
						),
						React.createElement(
							"span",
							{ className: "percent right" },
							percentRemaining
						)
					),
					React.createElement(Example, {
						name: this.props.item.name,
						progress: this.props.item.progress,
						amount: this.props.item.amount,
						onSave: this.onSave.bind(this)

					})
				)
			),
			React.createElement(
				"figure",
				{ className: "back" },
				React.createElement(
					"a",
					{ href: "#", className: "back-arrow", onClick: this.cancelEdit.bind(this, this.props.item.index) },
					React.createElement("i", { className: "fa fa-angle-left" })
				),
				React.createElement(
					"h3",
					{ className: "card-title" },
					"Goal Details"
				),
				React.createElement(
					"div",
					{ className: "input-container" },
					React.createElement(
						"label",
						{ name: "name", className: "descriptor" },
						"Name"
					),
					React.createElement("input", { type: "text", placeholder: "Goal Name", value: this.state.input1, onChange: this.handleChange.bind(this, 'input1') }),
					React.createElement(
						"label",
						{ name: "amount", className: "descriptor" },
						"Goal"
					),
					React.createElement(
						"span",
						{ className: "edit-money" },
						"$"
					),
					React.createElement("input", { type: "number", placeholder: "Amount", value: this.state.input2, onChange: this.handleChange.bind(this, 'input2') }),
					React.createElement(
						"label",
						{ name: "progress", className: "descriptor" },
						"Progress"
					),
					React.createElement(
						"span",
						{ className: "edit-money" },
						"$"
					),
					" ",
					React.createElement("input", { type: "number", placeholder: "Progress", value: this.state.input3, onChange: this.handleChange.bind(this, 'input3') }),
					"         ",
					React.createElement(
						"label",
						{ name: "icon", className: "descriptor" },
						"Icon"
					),
					React.createElement(
						"div",
						{ className: "dropdown-wrapper" },
						React.createElement(
							"select",
							{ value: this.state.selectValue,
								onChange: this.handleDropdown.bind(this)
							},
							React.createElement(
								"option",
								{ value: "car" },
								"Car"
							),
							React.createElement(
								"option",
								{ value: "plane" },
								"Plane"
							),
							React.createElement(
								"option",
								{ value: "" },
								"None"
							)
						)
					)
				),
				React.createElement("input", { type: "button", className: "button", value: "Save Changes", onClick: this.saveGoal.bind(this, this.props.item.index) }),
				React.createElement(
					"a",
					{ href: "#", className: "delete", onClick: this.deleteGoal.bind(this, this.props.item.index) },
					"Delete Goal"
				)
			)
		);
	};

	return GoalCard;
}(React.Component);

var Example = React.createClass({
	displayName: "Example",
	getInitialState: function getInitialState() {
		return { showModal: false,
			progress: this.props.progress,
			input1: "",
			sum: ""
		};
	},
	close: function close() {
		this.setState({ showModal: false });
	},
	submit: function submit(e) {
		if (e.key === 'Enter') {
			progressUpdate = this.state.sum;
			this.props.onSave();
			this.setState({
				showModal: false
			});
		}
	},
	save: function save() {
		progressUpdate = this.state.sum;
		this.props.onSave();
		this.setState({
			showModal: false
		});
	},
	open: function open() {
		this.setState({ showModal: true,
			sum: this.props.progress,
			input1: "" });
	},
	handleChange: function handleChange(name, e) {
		var change = {};
		change[name] = e.target.value;

		this.setState(change);
		this.setState({
			sum: Number(this.props.progress) + Number(change[name])

		});
	},
	render: function render() {

		return React.createElement(
			"div",
			null,
			React.createElement(
				Button,
				{
					bsStyle: "primary",
					bsSize: "large",
					onClick: this.open,
					className: "button"
				},
				"Add funds"
			),
			React.createElement(
				Modal,
				{ show: this.state.showModal, onHide: this.close },
				React.createElement(
					Modal.Header,
					{ closeButton: true },
					React.createElement(
						Modal.Title,
						null,
						"Add Funds for ",
						this.props.name
					)
				),
				React.createElement(
					Modal.Body,
					null,
					React.createElement(
						"label",
						null,
						"Current progress:"
					),
					React.createElement(
						"div",
						{ className: "data" },
						"$",
						this.props.progress.toLocaleString()
					),
					React.createElement(
						"label",
						null,
						"Add amount:"
					),
					React.createElement(
						"div",
						{ className: "data" },
						React.createElement(
							"span",
							{ className: "pre-money" },
							"$"
						),
						" ",
						React.createElement("input", { type: "number", className: "fund-container", defaultValue: "", onKeyPress: this.submit.bind(this), onChange: this.handleChange.bind(this, 'input1'), autoFocus: true })
					),
					React.createElement(
						"p",
						{ className: "smallprint" },
						" Total Progress: ",
						React.createElement(
							"span",
							{ className: "pre-money" },
							"$"
						),
						this.state.sum.toLocaleString()
					)
				),
				React.createElement(
					Modal.Footer,
					null,
					React.createElement(
						Button,
						{ onClick: this.close },
						"Close"
					),
					React.createElement(
						Button,
						{ type: "button", className: "btn-primary", onClick: this.save.bind(this, this.props) },
						"Update Progress"
					)
				)
			)
		);
	}
});

var GoalList = React.createClass({
	displayName: "GoalList",

	getInitialState: function getInitialState() {
		return {
			data: this.props.data
		};
	},
	dragStart: function dragStart(e) {
		//this.refs['update'].updateGoal();
		this.dragged = e.currentTarget;
		e.dataTransfer.effectAllowed = 'move';
		e.dataTransfer.setData("text/html", e.currentTarget);
	},
	dragEnd: function dragEnd(e) {
		this.dragged.style.display = "block";
		placeholder.remove();
		// Update data
		var data = this.state.data;
		var from = Number(this.dragged.dataset.id);
		var to = Number(this.over.dataset.id);
		if (from < to) to--;
		if (this.nodePlacement == "after") to++;
		data.splice(to, 0, data.splice(from, 1)[0]);
		this.setState({
			data: data
		});
	},
	dragOver: function dragOver(e) {

		e.preventDefault();
		this.dragged.style.display = "none";
		if (e.target.className == "placeholder") return;
		this.over = e.target;
		// Inside the dragOver method
		var relY = e.pageY - this.over.offsetTop;
		var height = this.over.offsetHeight / 2;
		var relX = e.pageX - this.over.offsetLeft;
		var width = this.over.offsetWidth / 2;
		var parent = e.target.parentNode;

		if (relX >= width) {
			this.nodePlacement = "after";
			parent.insertBefore(placeholder, e.target.nextElementSibling);
		} else {
			this.nodePlacement = "before";
			parent.insertBefore(placeholder, e.target);
		}
		this.setState({
			data: this.props.data
		});
	},
	onFlip: function onFlip(i) {
		var data = this.state.data;
		data[i].flipped = !data[i].flipped;

		this.setState({
			data: data });

		if (data[i].flipped) {
			var data = this.props.data;
			//	data[i].dragStatus = false;
			dragStatus = false;
		} else {
			//	data[i].dragStatus= true;
			dragStatus = true;
		}
	},
	onDelete: function onDelete(i) {
		var data = this.props.data;
		var newData = this.state.data.slice(); //copy array
		newData.splice(i, 1); //remove element
		this.setState({ data: newData }); //update state
		this.props = newData;
		//var data = this.props.data;
		data[i].flipped = !data[i].flipped;
		if (data[i].flipped) {

			//	data[i].dragStatus = false;
			dragStatus = false;
		} else {
			//	data[i].dragStatus= true;
			dragStatus = true;
		}
		data = newData;
		//data.splice(i, 1);

		//	this.setState({ data: data});
	},
	render: function render() {

		return React.createElement(
			"ul",
			{ className: "goal__list", onDragOver: this.dragOver },
			this.state.data.map(function (item, i) {

				return React.createElement(
					"li",
					{ "data-id": i,
						key: i
						// draggable={goals[i].dragStatus}
						, draggable: dragStatus,
						onDragEnd: this.dragEnd.bind(this),
						onDragStart: this.dragStart.bind(this)

					},
					React.createElement(GoalCard, { item: item,
						onFlip: this.onFlip.bind(this, i),
						cancelEdit: this.onFlip.bind(this, i),
						saveGoal: this.onFlip.bind(this, i),
						onDelete: this.onDelete.bind(this, i)

					})
				);
			}, this)
		);
	}

});

ReactDOM.render(React.createElement(GoalList, { data: goals }), document.getElementById('app'));