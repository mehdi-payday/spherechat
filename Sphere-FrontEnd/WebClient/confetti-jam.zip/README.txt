A Pen created at CodePen.io. You can find this one at http://codepen.io/elifitch/pen/apxxVL.

 Click to spew confetti

Forked with many 💖 from http://codepen.io/jscottsmith/pen/VjPaLO?editors=0010