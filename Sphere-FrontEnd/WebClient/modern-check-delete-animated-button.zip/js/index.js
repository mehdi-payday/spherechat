"use strict";

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function FaCheck(_ref) {
  var className = _ref.className;

  return React.createElement(
    "svg",
    { viewBox: "0 0 40 40", className: className },
    React.createElement(
      "g",
      null,
      React.createElement("path", { d: "m37.3 12.6q0 0.9-0.6 1.6l-19.2 19.1q-0.6 0.7-1.5 0.7t-1.6-0.7l-11.1-11.1q-0.6-0.6-0.6-1.5t0.6-1.5l3.1-3q0.6-0.7 1.5-0.7t1.5 0.7l6.6 6.5 14.6-14.6q0.6-0.6 1.5-0.6t1.5 0.6l3.1 3q0.6 0.6 0.6 1.5z" })
    )
  );
}

function FaClose(_ref2) {
  var className = _ref2.className;

  return React.createElement(
    "svg",
    { viewBox: "-0.5 2 40 40", className: className },
    React.createElement(
      "g",
      null,
      React.createElement("path", { d: "m33.5 29.5q0 0.9-0.7 1.5l-3 3.1q-0.6 0.6-1.5 0.6t-1.5-0.6l-6.6-6.6-6.5 6.6q-0.7 0.6-1.6 0.6t-1.5-0.6l-3-3.1q-0.6-0.6-0.6-1.5t0.6-1.5l6.5-6.6-6.5-6.5q-0.6-0.7-0.6-1.6t0.6-1.5l3-3q0.6-0.6 1.5-0.6t1.6 0.6l6.5 6.6 6.6-6.6q0.6-0.6 1.5-0.6t1.5 0.6l3.1 3q0.6 0.7 0.6 1.5t-0.6 1.6l-6.6 6.5 6.6 6.6q0.6 0.6 0.6 1.5z" })
    )
  );
}

var Toggle = function (_React$Component) {
  _inherits(Toggle, _React$Component);

  function Toggle() {
    var _temp, _this, _ret;

    _classCallCheck(this, Toggle);

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return _ret = (_temp = (_this = _possibleConstructorReturn(this, _React$Component.call.apply(_React$Component, [this].concat(args))), _this), _this.state = {
      isChecked: false
    }, _temp), _possibleConstructorReturn(_this, _ret);
  }

  Toggle.prototype.onToggle = function onToggle() {
    this.setState({
      isChecked: !this.state.isChecked
    });
  };

  Toggle.prototype.onDelete = function onDelete() {};

  Toggle.prototype.render = function render() {
    var isChecked = this.state.isChecked;

    return React.createElement(
      "div",
      { className: "optionsContainer" },
      React.createElement(
        "div",
        { className: "innerCircleGreen", onClick: this.onToggle.bind(this) },
        React.createElement(FaCheck, { className: "checkInactive " + (isChecked && 'checkActive') })
      ),
      React.createElement(
        "div",
        { className: "innerCircleRed", onClick: this.onDelete.bind(this) },
        React.createElement(FaClose, { className: "deleteIcon" })
      )
    );
  };

  return Toggle;
}(React.Component);

ReactDOM.render(React.createElement(Toggle, null), document.getElementById('react-main'));