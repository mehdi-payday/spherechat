A Pen created at CodePen.io. You can find this one at http://codepen.io/brettberry/pen/RoNaYv.

 Simple animated check and delete buttons (built with reactjs and scss). Originally made as action buttons for a To Do List web app. 