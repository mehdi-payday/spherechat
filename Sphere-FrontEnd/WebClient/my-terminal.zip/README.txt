A Pen created at CodePen.io. You can find this one at http://codepen.io/marcbizal/pen/VLKoam.

 This is basically just a mockup of iTerm on Mac OS X with some basic functionality. 
###Commands:
- **help:** displays a currently very unhelpful help message.
- **clear:** clears the terminal display.
- **fortune:** randomly selects a fortune from a [database](https://github.com/bmc/fortunes) by bmc on GitHub and displays it.