A Pen created at CodePen.io. You can find this one at http://codepen.io/rrenula/pen/qmaFb.

 Just another code editor made in pure CSS. It is based on an amazing Dribbble shot by Roy Barber. Said Dribbble shot here: http://dribbble.com/shots/1022371-Landing-Page-Element 

Prism syntax highlighter is used along with the line-numbers plugin and the Tomorrow-Theme.