A Pen created at CodePen.io. You can find this one at http://codepen.io/chrisdothtml/pen/LpPpyR.

 A fun little panel of elements that allow you to heart or hide them. Try fullscreen in mobile!

Mobile interactions include tapping or swiping panel elements.

Inspired by https://dribbble.com/shots/1464790--AEP-Delete-Action