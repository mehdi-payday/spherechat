A Pen created at CodePen.io. You can find this one at http://codepen.io/danzawadzki/pen/oZoQog.

 My first attempt to explore jQuery. The project created using HTML5, CSS3, jQuery, SASS, Normalize.js, Autoprefixer. A simple application running on the same scheme as thousands of existing applications with a list of tasks to do.